# CovidMAROC
This project is an android app tht helps the state to easely collect data about the people when they pass near eachother and store the data in the cloud for further use
this project uses the following libraries/frameworks:

  - Room Persistence Library: https://developer.android.com/topic/libraries/architecture/room
  - Nearby Connections: https://developers.google.com/nearby/connections/overview
  - Cloud Firestore: https://firebase.google.com/docs/firestore
  - WorkManager: https://developer.android.com/topic/libraries/architecture/workmanager
