package ma.fst.covidmaroc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.List;

import ma.fst.covidmaroc.model.Path;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PathsActivity extends AppCompatActivity {
    static String TAG = "PathsActivity";

    private APIInterface apiInterface;
    private ListView listView;
    private String cin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paths);
        apiInterface = APIClient.getClient().create(APIInterface.class);
        cin = getIntent().getStringExtra("cin");
        listView = (ListView)findViewById(R.id.listView);
        apiInterface.getPaths(cin).enqueue(new Callback<List<Path>>() {
            @Override
            public void onResponse(Call<List<Path>> call, Response<List<Path>> response) {
                listView.setAdapter(new CustomListAdapter(PathsActivity.this, response.body()));
            }

            @Override
            public void onFailure(Call<List<Path>> call, Throwable t) {
                Log.e(TAG, "onFailure: CANT GET PATHS", t);
            }
        });
    }
}